<template>
  <main>
    <RoomCode />
  </main>
</template>
