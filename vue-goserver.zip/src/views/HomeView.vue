<script setup>
import CrudForm from "@/components/CrudForm.vue";
</script>

<template>
  <main>
    <CrudForm />
  </main>
</template>
